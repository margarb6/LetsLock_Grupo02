package es.upv.gnd.letslock.bbdd;

public interface UsuariosCallback {

    void getUsuariosCallback(Usuario usuario);
}
